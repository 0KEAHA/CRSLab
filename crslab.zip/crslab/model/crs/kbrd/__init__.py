from .kbrd import KBRDModel
