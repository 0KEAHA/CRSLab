from .inspired_conv import InspiredConvModel
from .inspired_rec import InspiredRecModel
