from .mgcg import MGCGModel
