from .textcnn import TextCNNModel
