from .inspired import InspiredDataset
