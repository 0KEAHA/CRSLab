resources = {
    'pkuseg': {
        'version': '0.3',
        'folder_path': "huatuo_demo\pkuseg",
        'file' : "huatuo_demo\pkuseg",
        'special_token_idx': {
            'pad': 0,
            'start': 1,
            'end': 2,
            'unk': 3,
            'pad_entity': 0,
            'pad_word': 0,
            'pad_topic': 0
        },
    }
}